export class testClass {
    // Comments at class level

    constructor( p1, p2) {
    }

    static aStaticMethod() {
        // Static method documentation
    }

    aMethod() {
        // Instance method documentation
        // With more details
    }
}

export function aTestfunction(a,b) {
    // That one is a module function
    // With more details
}