if (! nort ) var nort={}

nort.info= {
    version: "0.5",
    date: new Date( 2020, 11, 13 )
}