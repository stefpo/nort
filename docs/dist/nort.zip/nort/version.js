if (! nort ) var nort={}

nort.info= {
    version: "0.6",
    date: new Date( 2023, 11, 5 )
}