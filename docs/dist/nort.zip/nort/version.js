
export const info= {
    version: "0.7",
    date: new Date( 2025, 11, 10 )
}

window.nortVersionInfo = info