
export const info= {
    version: "0.71",
    date: new Date( 2025, 11, 25 )
}

window.nortVersionInfo = info