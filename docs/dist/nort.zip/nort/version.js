
export const info= {
    version: "0.72",
    date: new Date( 2025, 11, 26 )
}

window.nortVersionInfo = info